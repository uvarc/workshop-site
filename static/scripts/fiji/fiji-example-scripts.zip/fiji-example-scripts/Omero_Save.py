from ij import IJ

imp = IJ.getImage()
IJ.run(imp, "OMERO... ", "")